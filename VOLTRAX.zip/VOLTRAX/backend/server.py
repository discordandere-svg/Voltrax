from fastapi import FastAPI, APIRouter
from starlette.middleware.cors import CORSMiddleware
import logging
from pydantic import BaseModel
from typing import Optional

app = FastAPI()
api_router = APIRouter(prefix="/api")

calculations_store = []


class CalculationInput(BaseModel):
    zonneproductie: float
    jaarverbruik: float
    teruglevering: float
    prijsInkoop: float
    prijsTeruglevering: float
    battery_kWh: float
    battery_price: float
    terugleververgoeding_value: Optional[float] = 0
    terugleververgoeding_unit: Optional[str] = "kWh"
    terugleverkosten_value: Optional[float] = 0
    terugleverkosten_unit: Optional[str] = "kWh"


class CalculationResult(BaseModel):
    smart_daily_low: float
    smart_daily_high: float
    smart_daily_display: float
    smart_annual_low: float
    smart_annual_high: float
    bill_savings_annual: float
    bill_savings_monthly: float
    total_annual_low: float
    total_annual_high: float
    total_daily_low: float
    total_daily_high: float
    payback_low: float
    payback_high: float
    zelfverbruik_voor: float
    zelfverbruik_na: float
    netonafhankelijkheid: float
    teruglevering_voor: float
    teruglevering_na: float
    opbrengst_10_jaar_low: float
    opbrengst_10_jaar_high: float
    netto_winst_10_jaar_low: float
    netto_winst_10_jaar_high: float
    bat_shift_kwh: float
    saved_terugleverkosten: float
    lost_terugleververgoeding: float


def clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def calculate_battery_savings(
    zonneproductie: float,
    jaarverbruik: float,
    teruglevering: float,
    pE: float,
    pT: float,
    bat_kWh: float,
    battery_price: float,
    terugleververgoeding_value: float = 0,
    terugleververgoeding_unit: str = "kWh",
    terugleverkosten_value: float = 0,
    terugleverkosten_unit: str = "kWh"
) -> dict:
    V = jaarverbruik
    T = teruglevering

    # ============================================================
    # STEP 1 — BASELINE (WITHOUT BATTERY)
    # ============================================================
    self_consumption_without = V * 0.35
    grid_import_without = V - self_consumption_without        # V * 0.65
    grid_cost_without = grid_import_without * pE
    export_loss_without = T * (pE - pT)                      # real opportunity cost of exports
    total_cost_without = grid_cost_without + export_loss_without

    # ============================================================
    # STEP 2 — BATTERY ENERGY SHIFT
    # utilization scales 74 % (small) → 84 % (large, per 150 kWh scale)
    # ============================================================
    utilization_factor = clamp(0.74 + bat_kWh / 150.0, 0.74, 0.84)
    shiftable_energy = min(T, bat_kWh * 365.0)
    shifted_kwh = shiftable_energy * utilization_factor

    new_self_consumption = self_consumption_without + shifted_kwh
    new_self_consumption = clamp(new_self_consumption, 0.0, V * 0.89)  # hard cap 89 %
    new_grid_import = max(0.0, V - new_self_consumption)

    # ============================================================
    # OPTIONAL: terugleverkosten / terugleververgoeding adjustments
    # ============================================================
    if terugleverkosten_unit == "kWh":
        terugleverkosten_annual = terugleverkosten_value * T
    else:
        terugleverkosten_annual = terugleverkosten_value

    if terugleververgoeding_unit == "kWh":
        terugleververgoeding_annual = terugleververgoeding_value * T
    else:
        terugleververgoeding_annual = terugleververgoeding_value

    shift_ratio = (shifted_kwh / T) if T > 0 else 0
    saved_terugleverkosten = terugleverkosten_annual * shift_ratio
    lost_terugleververgoeding = terugleververgoeding_annual * shift_ratio

    # ============================================================
    # STEP 3 — ENERGY SAVINGS (price spread × shifted kWh)
    # ============================================================
    energy_savings_raw = shifted_kwh * (pE - pT)
    energy_savings_raw += saved_terugleverkosten - lost_terugleververgoeding

    # ============================================================
    # STEP 4 — EMS / TRADING VALUE
    # ============================================================
    raw_trade_value = shifted_kwh * 0.225
    annual_trade_value_raw = clamp(raw_trade_value, 850.0, 1050.0)

    # ============================================================
    # STEP 5 — +5% PREMIUM UPLIFT on financial outputs
    # ============================================================
    PREMIUM = 1.05
    energy_savings = energy_savings_raw * PREMIUM
    annual_trade_value = annual_trade_value_raw * PREMIUM

    # Hard cap: EMS ≤ €1,150/yr
    annual_trade_value = min(annual_trade_value, 1150.0)

    # ============================================================
    # STEP 6 — TOTAL ANNUAL BENEFIT
    # ============================================================
    total_annual_benefit = energy_savings + annual_trade_value

    # Hard caps on total output
    total_annual_benefit = min(total_annual_benefit, 2300.0)
    daily_value = total_annual_benefit / 365.0
    if daily_value > 6.0:
        total_annual_benefit = 6.0 * 365.0
        daily_value = 6.0

    # Split into low/high range (±20% spread for display)
    total_annual_low = total_annual_benefit * 0.85
    total_annual_high = total_annual_benefit

    total_daily_low = total_annual_low / 365.0
    total_daily_high = total_annual_high / 365.0

    # Smart optimization display figures
    smart_annual_low = annual_trade_value * 0.85
    smart_annual_high = annual_trade_value
    smart_daily_display = annual_trade_value / 365.0
    smart_daily_low = smart_annual_low / 365.0
    smart_daily_high = smart_annual_high / 365.0

    bill_savings_annual = energy_savings
    bill_savings_monthly = energy_savings / 12.0

    # ============================================================
    # STEP 7 — ROI / PAYBACK (floor: 4.5 yr minimum)
    # ============================================================
    if total_annual_high > 0:
        payback_low = battery_price / total_annual_high
    else:
        payback_low = 99.0
    if total_annual_low > 0:
        payback_high = battery_price / total_annual_low
    else:
        payback_high = 99.0

    payback_low = max(4.5, payback_low)
    payback_high = max(payback_low, payback_high)

    # ============================================================
    # STEP 8 — SELF-CONSUMPTION & INDEPENDENCE
    # ============================================================
    zv_voor = 35.0
    zv_na_raw = (new_self_consumption / V * 100.0) if V > 0 else zv_voor
    zv_na = clamp(zv_na_raw, zv_voor, 89.0)   # hard cap 89 %

    teruglevering_voor = 100.0 - zv_voor
    teruglevering_na = 100.0 - zv_na
    net_voor = teruglevering_voor
    net_na = teruglevering_na
    netonafhankelijkheid_raw = ((net_voor - net_na) / net_voor * 100.0) if net_voor > 0 else 0.0
    netonafhankelijkheid = min(netonafhankelijkheid_raw, 88.0)  # hard cap 88 %

    opbrengst_10_jaar_low = total_annual_low * 10.0
    opbrengst_10_jaar_high = total_annual_high * 10.0
    netto_winst_10_jaar_low = opbrengst_10_jaar_low - battery_price
    netto_winst_10_jaar_high = opbrengst_10_jaar_high - battery_price

    return {
        "smart_daily_low": smart_daily_low,
        "smart_daily_high": smart_daily_high,
        "smart_daily_display": smart_daily_display,
        "smart_annual_low": smart_annual_low,
        "smart_annual_high": smart_annual_high,
        "bill_savings_annual": bill_savings_annual,
        "bill_savings_monthly": bill_savings_monthly,
        "total_annual_low": total_annual_low,
        "total_annual_high": total_annual_high,
        "total_daily_low": total_daily_low,
        "total_daily_high": total_daily_high,
        "payback_low": payback_low,
        "payback_high": payback_high,
        "zelfverbruik_voor": zv_voor,
        "zelfverbruik_na": zv_na,
        "netonafhankelijkheid": netonafhankelijkheid,
        "teruglevering_voor": teruglevering_voor,
        "teruglevering_na": teruglevering_na,
        "opbrengst_10_jaar_low": opbrengst_10_jaar_low,
        "opbrengst_10_jaar_high": opbrengst_10_jaar_high,
        "netto_winst_10_jaar_low": netto_winst_10_jaar_low,
        "netto_winst_10_jaar_high": netto_winst_10_jaar_high,
        "bat_shift_kwh": shifted_kwh,
        "saved_terugleverkosten": saved_terugleverkosten,
        "lost_terugleververgoeding": lost_terugleververgoeding,
    }


@api_router.get("/")
async def root():
    return {"message": "VOLTRAX API - AlphaESS Calculator"}


@api_router.post("/calculate", response_model=CalculationResult)
async def calculate(input_data: CalculationInput):
    results = calculate_battery_savings(
        zonneproductie=input_data.zonneproductie,
        jaarverbruik=input_data.jaarverbruik,
        teruglevering=input_data.teruglevering,
        pE=input_data.prijsInkoop,
        pT=input_data.prijsTeruglevering,
        bat_kWh=input_data.battery_kWh,
        battery_price=input_data.battery_price,
        terugleververgoeding_value=input_data.terugleververgoeding_value or 0,
        terugleververgoeding_unit=input_data.terugleververgoeding_unit or "kWh",
        terugleverkosten_value=input_data.terugleverkosten_value or 0,
        terugleverkosten_unit=input_data.terugleverkosten_unit or "kWh",
    )

    calculations_store.append({
        "input": input_data.model_dump(),
        "results": results
    })

    return CalculationResult(**results)


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)
