import React from 'react';
import { Link } from 'react-router-dom';
import { Zap, Mail, Phone, MapPin, BadgeCheck, Shield, Handshake } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl flex items-center justify-center">
                <Zap className="w-6 h-6 text-white" strokeWidth={2.5} />
              </div>
              <span className="text-2xl font-bold" style={{ fontFamily: 'Space Grotesk' }}>
                VOLTRAX
              </span>
            </div>
            <p className="text-gray-400 leading-relaxed mb-6 max-w-md">
              Officieel AlphaESS dealer en specialist in thuisbatterijen. Maximaliseer uw opbrengst uit zonnepanelen met intelligente energieopslag. Partner van het Nationaal Warmtefonds voor toegankelijke financiering.
            </p>

            {/* Trust badges */}
            <div className="flex flex-wrap gap-2 mb-6">
              {[
                { icon: BadgeCheck, label: 'Officieel AlphaESS Dealer' },
                { icon: Shield, label: 'NEN 1010 gecertificeerd' },
                { icon: Handshake, label: 'Warmtefonds Partner' },
              ].map((badge, i) => (
                <span key={i} className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/10 border border-white/15 rounded-full text-xs font-semibold text-gray-300">
                  <badge.icon className="w-3 h-3 text-emerald-400" />
                  {badge.label}
                </span>
              ))}
            </div>

            <div className="flex flex-col gap-3 text-gray-400">
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5" />
                <span>info@voltrax.nl</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5" />
                <span>+31 (0)20 123 4567</span>
              </div>
              <div className="flex items-center gap-3">
                <MapPin className="w-5 h-5" />
                <span>Nederland</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-bold text-lg mb-4" style={{ fontFamily: 'Space Grotesk' }}>Navigatie</h3>
            <ul className="space-y-3 text-gray-400">
              <li>
                <Link to="/" className="hover:text-emerald-400 transition-colors">Home</Link>
              </li>
              <li>
                <a href="#hoe-werkt-het" className="hover:text-emerald-400 transition-colors">Hoe werkt het</a>
              </li>
              <li>
                <a href="#product" className="hover:text-emerald-400 transition-colors">Product</a>
              </li>
              <li>
                <Link to="/calculator" className="hover:text-emerald-400 transition-colors">Calculator</Link>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="font-bold text-lg mb-4" style={{ fontFamily: 'Space Grotesk' }}>Informatie</h3>
            <ul className="space-y-3 text-gray-400">
              <li>
                <a href="#" className="hover:text-emerald-400 transition-colors">Over ons</a>
              </li>
              <li>
                <a href="#" className="hover:text-emerald-400 transition-colors">Warmtefonds aanvragen</a>
              </li>
              <li>
                <a href="#" className="hover:text-emerald-400 transition-colors">Privacy Policy</a>
              </li>
              <li>
                <a href="#" className="hover:text-emerald-400 transition-colors">Algemene voorwaarden</a>
              </li>
              <li>
                <a href="#" className="hover:text-emerald-400 transition-colors">Contact</a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-700 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-400 text-sm">
            © 2025 VOLTRAX. Alle rechten voorbehouden.
          </p>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-gray-500 text-xs">
            <span>Officieel AlphaESS Dealer</span>
            <span className="text-gray-700">·</span>
            <span>10 jaar garantie</span>
            <span className="text-gray-700">·</span>
            <span>CE / TÜV / IEC</span>
            <span className="text-gray-700">·</span>
            <span>NEN 1010</span>
            <span className="text-gray-700">·</span>
            <span>Warmtefonds Partner</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
