import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Menu, X, Zap } from 'lucide-react';
import { Button } from './ui/button';

const Header = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white/80 backdrop-blur-xl shadow-sm' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl flex items-center justify-center transform group-hover:scale-105 transition-transform">
              <Zap className="w-6 h-6 text-white" strokeWidth={2.5} />
            </div>
            <span className="text-2xl font-bold tracking-tight" style={{ fontFamily: 'Space Grotesk' }}>
              VOLTRAX
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-8">
            <a href="#hoe-werkt-het" className="text-gray-700 hover:text-emerald-600 transition-colors font-medium">
              Hoe werkt het
            </a>
            <a href="#product" className="text-gray-700 hover:text-emerald-600 transition-colors font-medium">
              Product
            </a>
            <a href="#voordelen" className="text-gray-700 hover:text-emerald-600 transition-colors font-medium">
              Voordelen
            </a>
            <Button
              onClick={() => navigate('/calculator')}
              className="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white px-6 py-2.5 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all"
            >
              Bereken besparing
            </Button>
          </nav>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {mobileMenuOpen && (
          <motion.nav
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden mt-4 pb-4 flex flex-col gap-4"
          >
            <a href="#hoe-werkt-het" className="text-gray-700 hover:text-emerald-600 transition-colors font-medium py-2">
              Hoe werkt het
            </a>
            <a href="#product" className="text-gray-700 hover:text-emerald-600 transition-colors font-medium py-2">
              Product
            </a>
            <a href="#voordelen" className="text-gray-700 hover:text-emerald-600 transition-colors font-medium py-2">
              Voordelen
            </a>
            <Button
              onClick={() => {
                navigate('/calculator');
                setMobileMenuOpen(false);
              }}
              className="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white px-6 py-3 rounded-xl font-semibold w-full"
            >
              Bereken besparing
            </Button>
          </motion.nav>
        )}
      </div>
    </motion.header>
  );
};

export default Header;
