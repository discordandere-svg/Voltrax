#!/usr/bin/env python3
"""
Backend API Tests for VOLTRAX AlphaESS Calculator
Tests all endpoints and calculation logic
"""

import requests
import json
from typing import Dict, Any

# Backend URL from environment
BACKEND_URL = "https://solar-storage-hub-2.preview.emergentagent.com"
API_BASE = f"{BACKEND_URL}/api"

class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    END = '\033[0m'
    BOLD = '\033[1m'

def print_test_header(test_name: str):
    print(f"\n{Colors.BLUE}{Colors.BOLD}{'='*80}{Colors.END}")
    print(f"{Colors.BLUE}{Colors.BOLD}TEST: {test_name}{Colors.END}")
    print(f"{Colors.BLUE}{Colors.BOLD}{'='*80}{Colors.END}")

def print_success(message: str):
    print(f"{Colors.GREEN}✓ {message}{Colors.END}")

def print_error(message: str):
    print(f"{Colors.RED}✗ {message}{Colors.END}")

def print_warning(message: str):
    print(f"{Colors.YELLOW}⚠ {message}{Colors.END}")

def print_info(message: str):
    print(f"{Colors.BLUE}ℹ {message}{Colors.END}")


def test_root_endpoint():
    """Test 1: Root endpoint should return welcome message"""
    print_test_header("Root Endpoint - GET /api/")
    
    try:
        response = requests.get(f"{API_BASE}/", timeout=10)
        print_info(f"Status Code: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            print_info(f"Response: {json.dumps(data, indent=2)}")
            
            if data.get("message") == "VOLTRAX API - AlphaESS Calculator":
                print_success("Root endpoint returns correct message")
                return True
            else:
                print_error(f"Unexpected message: {data.get('message')}")
                return False
        else:
            print_error(f"Expected status 200, got {response.status_code}")
            return False
            
    except Exception as e:
        print_error(f"Request failed: {str(e)}")
        return False


def test_calculator_realistic_data():
    """Test 2: Calculator with realistic data"""
    print_test_header("Calculator Endpoint - Realistic Data")
    
    test_data = {
        "zonneproductie": 8000,
        "jaarverbruik": 4500,
        "teruglevering": 4000,
        "prijsInkoop": 0.30,
        "prijsTeruglevering": 0.09,
        "prijsKorting": 0.05,
        "battery_kWh": 18.6,
        "battery_price": 9999
    }
    
    print_info(f"Input Data: {json.dumps(test_data, indent=2)}")
    
    try:
        response = requests.post(f"{API_BASE}/calculate", json=test_data, timeout=10)
        print_info(f"Status Code: {response.status_code}")
        
        if response.status_code != 200:
            print_error(f"Expected status 200, got {response.status_code}")
            print_error(f"Response: {response.text}")
            return False
        
        result = response.json()
        print_info(f"Response: {json.dumps(result, indent=2)}")
        
        # Check all required fields
        required_fields = [
            "jaarlijkse_besparing",
            "maandelijkse_besparing",
            "terugverdientijd",
            "opbrengst_10_jaar",
            "netto_winst_10_jaar",
            "zelfverbruik_voor",
            "zelfverbruik_na",
            "teruglevering_voor",
            "teruglevering_na",
            "besparing_eigen_gebruik",
            "netoptimalisatie_inkomsten",
            "besparing_terugleverkosten"
        ]
        
        all_fields_present = True
        for field in required_fields:
            if field not in result:
                print_error(f"Missing field: {field}")
                all_fields_present = False
            else:
                print_success(f"{field}: {result[field]}")
        
        if not all_fields_present:
            return False
        
        # Validate values
        issues = []
        
        # Check positive besparing
        if result["jaarlijkse_besparing"] <= 0:
            issues.append(f"jaarlijkse_besparing should be positive, got {result['jaarlijkse_besparing']}")
        
        # Check zelfverbruik_na > zelfverbruik_voor
        if result["zelfverbruik_na"] <= result["zelfverbruik_voor"]:
            issues.append(f"zelfverbruik_na ({result['zelfverbruik_na']}) should be higher than zelfverbruik_voor ({result['zelfverbruik_voor']})")
        
        # Check no negative values
        for field, value in result.items():
            if isinstance(value, (int, float)) and value < 0:
                issues.append(f"{field} is negative: {value}")
        
        # Check zelfverbruik_na is realistic (between voor and 96%)
        if not (result["zelfverbruik_voor"] <= result["zelfverbruik_na"] <= 96):
            issues.append(f"zelfverbruik_na ({result['zelfverbruik_na']}) should be between {result['zelfverbruik_voor']} and 96%")
        
        if issues:
            for issue in issues:
                print_error(issue)
            return False
        
        print_success("All validations passed for realistic data")
        return True
        
    except Exception as e:
        print_error(f"Request failed: {str(e)}")
        return False


def test_battery_sizes():
    """Test 3: Different battery sizes with diminishing returns"""
    print_test_header("Battery Sizes - Diminishing Returns Test")
    
    battery_sizes = [9.3, 18.6, 27.9, 46.5, 55.8]
    battery_prices = [4999, 9999, 14999, 19999, 24999]
    
    base_data = {
        "zonneproductie": 8000,
        "jaarverbruik": 4500,
        "teruglevering": 4000,
        "prijsInkoop": 0.30,
        "prijsTeruglevering": 0.09,
        "prijsKorting": 0.05
    }
    
    results = []
    
    for battery_kWh, battery_price in zip(battery_sizes, battery_prices):
        test_data = {
            **base_data,
            "battery_kWh": battery_kWh,
            "battery_price": battery_price
        }
        
        print_info(f"\nTesting battery size: {battery_kWh} kWh (€{battery_price})")
        
        try:
            response = requests.post(f"{API_BASE}/calculate", json=test_data, timeout=10)
            
            if response.status_code != 200:
                print_error(f"Request failed with status {response.status_code}")
                return False
            
            result = response.json()
            results.append({
                "battery_kWh": battery_kWh,
                "battery_price": battery_price,
                "jaarlijkse_besparing": result["jaarlijkse_besparing"],
                "zelfverbruik_na": result["zelfverbruik_na"],
                "terugverdientijd": result["terugverdientijd"],
                "netto_winst_10_jaar": result["netto_winst_10_jaar"]
            })
            
            print_success(f"  Jaarlijkse besparing: €{result['jaarlijkse_besparing']:.2f}")
            print_success(f"  Zelfverbruik na: {result['zelfverbruik_na']:.1f}%")
            print_success(f"  Terugverdientijd: {result['terugverdientijd']:.1f} jaar")
            
        except Exception as e:
            print_error(f"Request failed: {str(e)}")
            return False
    
    # Verify larger batteries give better results (with diminishing returns)
    print_info("\nVerifying diminishing returns pattern...")
    
    issues = []
    
    for i in range(len(results) - 1):
        current = results[i]
        next_battery = results[i + 1]
        
        # Larger battery should have higher or equal besparing
        if next_battery["jaarlijkse_besparing"] < current["jaarlijkse_besparing"]:
            issues.append(
                f"Battery {next_battery['battery_kWh']} kWh has LOWER besparing "
                f"(€{next_battery['jaarlijkse_besparing']:.2f}) than "
                f"{current['battery_kWh']} kWh (€{current['jaarlijkse_besparing']:.2f})"
            )
        
        # Larger battery should have higher or equal zelfverbruik
        if next_battery["zelfverbruik_na"] < current["zelfverbruik_na"]:
            issues.append(
                f"Battery {next_battery['battery_kWh']} kWh has LOWER zelfverbruik "
                f"({next_battery['zelfverbruik_na']:.1f}%) than "
                f"{current['battery_kWh']} kWh ({current['zelfverbruik_na']:.1f}%)"
            )
    
    # Check for diminishing returns (improvement should decrease)
    improvements = []
    for i in range(len(results) - 1):
        improvement = results[i + 1]["jaarlijkse_besparing"] - results[i]["jaarlijkse_besparing"]
        improvements.append(improvement)
        print_info(f"Improvement from {results[i]['battery_kWh']} to {results[i+1]['battery_kWh']} kWh: €{improvement:.2f}")
    
    # Verify diminishing returns (each step should add less than previous, with some tolerance)
    for i in range(len(improvements) - 1):
        if improvements[i + 1] > improvements[i] * 1.1:  # 10% tolerance
            print_warning(
                f"Improvement is increasing instead of diminishing: "
                f"€{improvements[i]:.2f} -> €{improvements[i+1]:.2f}"
            )
    
    if issues:
        for issue in issues:
            print_error(issue)
        return False
    
    print_success("All battery sizes show correct progression with diminishing returns")
    return True


def test_edge_cases():
    """Test 4: Edge cases"""
    print_test_header("Edge Cases")
    
    test_cases = [
        {
            "name": "Zeer klein batterij (9.3 kWh)",
            "data": {
                "zonneproductie": 8000,
                "jaarverbruik": 4500,
                "teruglevering": 4000,
                "prijsInkoop": 0.30,
                "prijsTeruglevering": 0.09,
                "prijsKorting": 0.05,
                "battery_kWh": 9.3,
                "battery_price": 4999
            }
        },
        {
            "name": "Zeer groot batterij (55.8 kWh)",
            "data": {
                "zonneproductie": 8000,
                "jaarverbruik": 4500,
                "teruglevering": 4000,
                "prijsInkoop": 0.30,
                "prijsTeruglevering": 0.09,
                "prijsKorting": 0.05,
                "battery_kWh": 55.8,
                "battery_price": 24999
            }
        },
        {
            "name": "Hoog verbruik (8000 kWh)",
            "data": {
                "zonneproductie": 10000,
                "jaarverbruik": 8000,
                "teruglevering": 3000,
                "prijsInkoop": 0.30,
                "prijsTeruglevering": 0.09,
                "prijsKorting": 0.05,
                "battery_kWh": 18.6,
                "battery_price": 9999
            }
        },
        {
            "name": "Laag verbruik (2500 kWh)",
            "data": {
                "zonneproductie": 6000,
                "jaarverbruik": 2500,
                "teruglevering": 4000,
                "prijsInkoop": 0.30,
                "prijsTeruglevering": 0.09,
                "prijsKorting": 0.05,
                "battery_kWh": 18.6,
                "battery_price": 9999
            }
        }
    ]
    
    all_passed = True
    
    for test_case in test_cases:
        print_info(f"\nTesting: {test_case['name']}")
        
        try:
            response = requests.post(f"{API_BASE}/calculate", json=test_case['data'], timeout=10)
            
            if response.status_code != 200:
                print_error(f"Request failed with status {response.status_code}")
                all_passed = False
                continue
            
            result = response.json()
            
            # Check for negative values (but netto_winst_10_jaar can be negative - that's realistic!)
            has_invalid_negative = False
            fields_that_should_not_be_negative = [
                "jaarlijkse_besparing",
                "maandelijkse_besparing",
                "terugverdientijd",
                "opbrengst_10_jaar",
                "zelfverbruik_voor",
                "zelfverbruik_na",
                "teruglevering_voor",
                "teruglevering_na",
                "besparing_eigen_gebruik",
                "netoptimalisatie_inkomsten",
                "besparing_terugleverkosten"
            ]
            
            for field in fields_that_should_not_be_negative:
                if field in result and result[field] < 0:
                    print_error(f"  {field} is negative: {result[field]}")
                    has_invalid_negative = True
            
            if has_invalid_negative:
                all_passed = False
                continue
            
            # Check zelfverbruik_na is realistic
            if not (result["zelfverbruik_voor"] <= result["zelfverbruik_na"] <= 96):
                print_error(
                    f"  zelfverbruik_na ({result['zelfverbruik_na']:.1f}%) is not realistic "
                    f"(should be between {result['zelfverbruik_voor']:.1f}% and 96%)"
                )
                all_passed = False
                continue
            
            print_success(f"  Jaarlijkse besparing: €{result['jaarlijkse_besparing']:.2f}")
            print_success(f"  Zelfverbruik: {result['zelfverbruik_voor']:.1f}% -> {result['zelfverbruik_na']:.1f}%")
            print_success(f"  Terugverdientijd: {result['terugverdientijd']:.1f} jaar")
            print_success(f"  Passed all validations")
            
        except Exception as e:
            print_error(f"  Request failed: {str(e)}")
            all_passed = False
    
    return all_passed


def run_all_tests():
    """Run all backend tests"""
    print(f"\n{Colors.BOLD}{'='*80}{Colors.END}")
    print(f"{Colors.BOLD}VOLTRAX AlphaESS Calculator - Backend API Tests{Colors.END}")
    print(f"{Colors.BOLD}Backend URL: {BACKEND_URL}{Colors.END}")
    print(f"{Colors.BOLD}{'='*80}{Colors.END}")
    
    tests = [
        ("Root Endpoint", test_root_endpoint),
        ("Calculator - Realistic Data", test_calculator_realistic_data),
        ("Battery Sizes - Diminishing Returns", test_battery_sizes),
        ("Edge Cases", test_edge_cases)
    ]
    
    results = {}
    
    for test_name, test_func in tests:
        try:
            results[test_name] = test_func()
        except Exception as e:
            print_error(f"Test '{test_name}' crashed: {str(e)}")
            results[test_name] = False
    
    # Summary
    print(f"\n{Colors.BOLD}{'='*80}{Colors.END}")
    print(f"{Colors.BOLD}TEST SUMMARY{Colors.END}")
    print(f"{Colors.BOLD}{'='*80}{Colors.END}")
    
    passed = sum(1 for result in results.values() if result)
    total = len(results)
    
    for test_name, result in results.items():
        if result:
            print_success(f"{test_name}: PASSED")
        else:
            print_error(f"{test_name}: FAILED")
    
    print(f"\n{Colors.BOLD}Total: {passed}/{total} tests passed{Colors.END}")
    
    if passed == total:
        print(f"{Colors.GREEN}{Colors.BOLD}✓ ALL TESTS PASSED{Colors.END}")
        return True
    else:
        print(f"{Colors.RED}{Colors.BOLD}✗ SOME TESTS FAILED{Colors.END}")
        return False


if __name__ == "__main__":
    success = run_all_tests()
    exit(0 if success else 1)
